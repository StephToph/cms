// application/libraries/MyLibrary.php
<?php
class MyLibrary {
    public function sharedFunction() {
        // Your shared functionality
        return 'Shared functionality executed!';
    }
}


?>